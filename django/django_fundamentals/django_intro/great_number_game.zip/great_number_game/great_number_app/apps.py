from django.apps import AppConfig


class GreatNumberAppConfig(AppConfig):
    name = 'great_number_app'
