from django.shortcuts import render,redirect
from .models import Show
# Create your views here.
def root(request):

    context = {
        'all_shows': Show.objects.all(),
    }

    return render(request, 'index.html',context)


def new(request):
    context = {
        'all_shows': Show.objects.all(),
    }
    
    return render(request, 'new_show.html',context)

def add_new(request):
    request.session['network'] = request.POST['network']
    request.session['title'] = request.POST['title']
    request.session['desc'] = request.POST['desc']
    request.session['release_date'] = request.POST['release_date']
    new_show_create = Show.objects.create(network = request.session['network'],title= request.session['title'], desc = request.session['desc'], release_date = request.session['release_date'])
    return redirect('/')



def edit(request, id):
    context = {
        'all_shows': Show.objects.all(),
        'this_show': Show.objects.get(id = id)
    }

    return render(request, 'edit_show.html', context)

def edit_show(request,id):

    show_to_update = Show.objects.get(id=id)
    show_to_update.network = request.POST['network']
    show_to_update.title = request.POST['title']
    show_to_update.description = request.POST['desc']
    show_to_update.release_date = request.POST['release_date']
    show_to_update.save()	# then -0

    return redirect('/')

def show(request, id):
    context = {
        'all_shows': Show.objects.all(),
        'this_show': Show.objects.get(id = id)
    }
    request.session['id'] = id
    

    return render(request, 'show_info.html',context)


def delete(request, id):
    Show.objects.get(id=id).delete()
    return redirect("/")