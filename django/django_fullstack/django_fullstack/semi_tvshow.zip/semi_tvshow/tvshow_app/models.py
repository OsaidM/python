from django.db import models

# Create your models here.
class Show(models.Model):
    network = models.CharField(max_length = 255)
    title = models.CharField(max_length = 255)
    desc = models.TextField(max_length = 255)
    release_date = models.DateField(null = True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)



#Show.objects.create(network= "Netflix", title = "Stranger Things", release_date="July 15, 2016")
