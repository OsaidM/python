from django.apps import AppConfig


class TvshowAppConfig(AppConfig):
    name = 'tvshow_app'
