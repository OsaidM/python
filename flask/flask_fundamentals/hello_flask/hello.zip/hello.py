from flask import Flask  # Import Flask to allow us to create our app
app = Flask(__name__)    # Create a new instance of the Flask class called "app"
@app.route('/')          # The "@" decorator associates this route with the function immediately following
def hello_world():
    return 'Hello World!'  # Return the string 'Hello World!' as a response

@app.route('/<name>')
def hello_world2(name):
    if name == 'dojo':
        return 'Hello dojo'
    else: return '"Sorry! No response. Try again."'

@app.route('/say/<name>')
def hello_world3(name):
    if name == 'flask' or name == 'michael' or name == 'john':
        return 'HI '+ name + '!' 
    else: return '"Sorry! No response. Try again."'

@app.route('/<num>/<name>')
def hello_world4(num = 35, name = 'hello'):
    return (name + '\n') * int(num)

@app.route('/<num>/<name>')
def hello_world5(num = 80,name = "bye"):
    return (name + '\n') * int(num)

@app.route('/<num>/<name>')
def hello_world6(num = 99,name = "dogs"):
    return (name + '\n') * int(num)




if __name__=="__main__":   # Ensure this file is being run directly and not from a different module    
    app.run(debug=True)    # Run the app in debug mode.
