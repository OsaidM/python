from flask import Flask, render_template  # added render_template!
app = Flask(__name__)                     


@app.route('/play')                           
def hello_world(times = 3):
    # Instead of returning a string, 
    # we'll return the result of the render_template method, passing in the name of our HTML file
    
    return render_template('index.html', times = int(times))  

@app.route('/play/<times>')                           
def hello_world2(times):
    # Instead of returning a string, 
    # we'll return the result of the render_template method, passing in the name of our HTML file
    
    return render_template('index.html', times = int(times))  

@app.route('/play/<times>/<color>')                           
def hello_world3(times, color):
    # Instead of returning a string, 
    # we'll return the result of the render_template method, passing in the name of our HTML file
    
    return render_template('index.html', times = int(times), color = color)  


if __name__=="__main__":
    app.run(debug=True)   