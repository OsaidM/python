1.
#def countDown(num):
#	newList = []
#	for num in range(num,-1,-1):
#		newList.append(num)
#	return newList
#print(countDown(6))

2.
#def pandReturn(list = []):
#	print(list[0])
#	return list[1]
#
#print(pandReturn(list = [1,2]))

3.
#def fpLength(list = []):
#	sum = list[0] + len(list)
#	return sum
#print(fpLength([1,2,3,4,5]))

4.
#def vgtSecond(list = []):
#	if len(list) < 2:
#		return false
#	newList = []
#	max = list[1]
#	for i in range(0,len(list),1):
#		if list[i] > max:
#			newList.append(list[i])
#	print(len(newList))
#	return newList 

#print(vgtSecond([5,2,3,2,1,4]))

5.
#def thisLengthThatValue(size,value):
#	newList = []
#	for i in range(0,size,1):
#		newList.append(value)
#	return newList
#print(thisLengthThatValue(4,7))
