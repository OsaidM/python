print("Hello World!")

myName = "Osaid"

print("Hello", myName)

print("Hello "+ myName)

favNumber = 8
print("Hello", format(favNumber))

print("Hello "+ format(favNumber))

food1 = "noidea"
food2 = "noidea2"

print("I love to eat {} {}".format(food1,food2))

print(f"I love to eat {food1} {food2}")

