class User:
    def __init__(self, name, balance):
        self.name = name
        self.account_balance = balance
        
    def make_withdrawal(self,amount):
        self.account_balance -= amount
        return self.account_balance
    
    def make_deposit(self, deposit):
        self.account_balance += deposit
        return self.account_balance
        
    def display_user_balance(self):
        print(self.name, self.account_balance)
        
    def transfer_money(self, other_user, amount):
        self.account_balance -= amount
        other_user.account_balance += amount
instance1 = User('osaid', 300)
instance2 = User('mhamad', 500)
instance3 = User('samer', 800)


instance1.make_deposit(500)
instance1.make_deposit(30)
instance1.make_deposit(100)
instance1.make_withdrawal(200)
instance3.make_deposit(150)
instance3.make_withdrawal(90)
instance3.make_withdrawal(20)
instance3.make_withdrawal(75)
instance1.display_user_balance()
instance3.display_user_balance()
instance1.transfer_money(instance2, 260)
instance2.display_user_balance()

